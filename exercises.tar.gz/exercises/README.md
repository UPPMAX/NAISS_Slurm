# Exercises 

Each of the centres have a subdirectory. If you are using a different centre than the ones listed, look in the subfolder "other".
