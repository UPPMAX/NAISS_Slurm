# Exercises 

Each of the installations has a subdirectory.  If you are using a different system than the ones listed, look in the subfolder "other" for a starting point.
