# Exercises 

There is a directory for each cluster that we are supporting during this course. 
Each exercise has a corresponding subdirectory. 
If you are using a different cluster than the ones listed, you may check the "other" directory for a starting point. 


