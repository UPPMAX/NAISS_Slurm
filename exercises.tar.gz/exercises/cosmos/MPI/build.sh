#!/bin/bash

# load a modern compiler and make MPI available
module load foss/2023b

# build the excutable
make

