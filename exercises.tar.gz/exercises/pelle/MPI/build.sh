#!/bin/bash

# load a modern compiler and make MPI available
ml foss/2023b

# build the executables
make

