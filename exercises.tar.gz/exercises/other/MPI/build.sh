#!/bin/bash

# load a modern compiler and make MPI available
module load MODULES

# build the executable
make

