#!/bin/bash

# load a modern compiler with OpenMP library
module load PDC/24.11 

# build the executable
make

