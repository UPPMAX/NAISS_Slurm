#!/bin/bash

# Project id - change to your own!
#SBATCH -A <proj-id>

# Number of cores per tasks
#SBATCH -c 8 

# Asking for a walltime of 5 min
#SBATCH --time=00:05:00
#SBATCH -p shared 


#SBATCH -o process_omp_%j.out  
#SBATCH -e process_omp_%j.err 

cat $0

# Load a compiler toolchain so we can run an OpenMP program
module load cpe/24.11 

# Set OMP_NUM_THREADS to the same value as -c with a fallback in case it isn't set.
# SLURM_CPUS_PER_TASK is set to the value of -c, but only if -c is explicitly set
if [ -n "$SLURM_CPUS_PER_TASK" ]; then
  omp_threads=$SLURM_CPUS_PER_TASK
else
  omp_threads=1
fi
export OMP_NUM_THREADS=$omp_threads

./omp_hello
