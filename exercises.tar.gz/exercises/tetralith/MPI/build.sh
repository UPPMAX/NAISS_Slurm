#!/bin/bash

# load a modern compiler and make MPI available
ml buildenv-gcc/2023b-eb

# build the executable
make

